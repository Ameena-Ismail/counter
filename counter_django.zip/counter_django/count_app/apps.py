from django.apps import AppConfig


class CountAppConfig(AppConfig):
    name = 'count_app'
